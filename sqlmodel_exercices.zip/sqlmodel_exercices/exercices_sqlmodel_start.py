"""
Exercices SQLModel — fichier à compléter.

Remplacez chaque zone marquée "TODO" par votre code, puis lancez :
    pytest test_exercices_sqlmodel.py -v

Pour ne lancer qu'un seul exercice :
    pytest test_exercices_sqlmodel.py -k exercice1 -v

Installation requise (une seule fois) :
    pip install sqlmodel pytest
"""

from sqlmodel import SQLModel, Field, Relationship


# ---------------------------------------------------------------------------
# TODO — Exercice 1 (★☆☆☆☆) — Un schéma pur, sans table
#
# Créez TagRead : un seul champ name: str. Ce n'est PAS une table.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# TODO — Exercice 2 (★★☆☆☆) — Votre première vraie table
#
# Créez Category, une VRAIE table : id (clé primaire, optionnelle),
# name: str.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# TODO — Exercice 3 (★★★☆☆) — Champ optionnel avec valeur par défaut
#
# Modifiez Category ci-dessus pour ajouter description: str | None = None.
# (Ne créez pas une deuxième classe Category : modifiez celle de l'exercice 2.)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# TODO — Exercice 4 (★★★☆☆) — Refactoring
#
# Créez Product, une vraie table : id (clé primaire, optionnelle),
# name: str, price: float strictement positif (price > 0).
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# TODO — Exercice 5 (★★★★☆) — Hiérarchie complète
#
# Créez BookBase (title: str, author: str), Book (vraie table, ajoute
# id et isbn: str), BookCreate (BookBase + isbn), BookPublic (BookBase + id).
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# TODO — Exercice 6 (★★★★★) — Relation entre deux tables
#
# Créez Author (id, name, novels: liste de Novel) et Novel (id, title,
# author_id en clé étrangère vers author.id, author: relation vers Author).
# ---------------------------------------------------------------------------
